
import asyncio
import websockets
import sys
import subprocess
import time
import os
import json

import pathlib
import ssl

#ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
#localhost_pem = pathlib.Path(__file__).with_name("cert.pem")
#ssl_context.load_cert_chain(localhost_pem)


from phone import handleDial
from dbHandler import initializeInformation
'''
Initialization process
'''
initializeInformation()

async def handlePhoneCall(websocket, path):
    async for message in websocket:

        path = path.replace("/websocket","")

        # Start call handled by HTTP        
        filepath = "./live_recordings" + path + "-" + str(time.time())

        # Save the parsed message
        with open(filepath + ".webm", 'wb') as output_file:
            output_file.write(message)
        
        # Convert the file from 'webm' to 'wav' for processing
        # Check return code
        subprocess.call(f'ffmpeg -i "{filepath}.webm" -vn "{filepath}.wav" -y -hide_banner -loglevel error', shell=True)

        call_id = path.replace("/", "")
        m = handleDial(filepath + ".wav", call_id)

        if(type(m) == dict):
            m = [m]

        # Only send back data if 'm' is useful.
        if(m != False and m != None):
            await websocket.send(json.dumps(m))
        
        # Remove the recordings
        os.remove(filepath + ".webm")
        os.remove(filepath + ".wav")

# Event loop for the websocket
# https://websockets.readthedocs.io/en/stable/howto/quickstart.html#encrypt-connections
asyncio.get_event_loop().run_until_complete(
    websockets.serve(handlePhoneCall, "0.0.0.0", 8000))

asyncio.get_event_loop().run_forever()
