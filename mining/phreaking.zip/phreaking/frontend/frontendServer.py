#!/usr/bin/env python
# Inspired by  https://stackoverflow.com/a/25708957/51280
# https://gist.github.com/opyate/6e5fcabc6f41474d248613c027373856
from http.server import SimpleHTTPRequestHandler
import socketserver
from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl

class MyHTTPRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_my_headers()
        SimpleHTTPRequestHandler.end_headers(self)

    def send_my_headers(self):
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")


if __name__ == '__main__':
    #with socketserver.HTTPServer(("", 3000), MyHTTPRequestHandler) as httpd:
    httpd = HTTPServer(('', 3000), MyHTTPRequestHandler)
    #httpd.socket = ssl.wrap_socket (httpd.socket,
    #keyfile="../key.pem",
    #certfile='../cert.pem', server_side=True)
    httpd.serve_forever()
